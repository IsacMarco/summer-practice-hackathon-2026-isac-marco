import { cardClass, cardTitleClass } from '../components/ui'
import SessionsCard from '../components/SessionsCard'
import MatchCard from '../components/MatchCard'
import ManualEventCard from '../components/ManualEventCard'
import AvailabilityCard from '../components/AvailabilityCard'
import NoticeBanner from '../components/NoticeBanner'

/**
 * Pagina de Sesiuni - Gestionează vizualizarea, crearea și potrivirea (matching) sesiunilor.
 */
export default function SessionsPage({
    notice,
    errorMessage,
    sessions,
    formatSessionTime,
    onLeaveSession,
    // Props pentru Matching
    availability,
    onUpdateAvailability,
    sports,
    onRunMatch,
    matching,
    // Props pentru Eveniment Manual
    locations,
    onCreateManualEvent
}) {
    return (
        <main className="mx-auto max-w-7xl px-6 py-10">
            <div className="soft-rise space-y-10">
                {/* Banner pentru feedback utilizator */}
                <NoticeBanner notice={notice} error={errorMessage} />

                <header className="space-y-2">
                    <h1 className="text-4xl font-extrabold tracking-tight text-slate-800">
                        Sports Sessions
                    </h1>
                    <p className="text-lg text-slate-600">
                        Manage your current activities or find new teammates.
                    </p>
                </header>

                <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">

                    {/* COLOANA 1 & 2: Sesiuni Active și Creare Manuală */}
                    <div className="space-y-10 lg:col-span-2">

                        {/* Secțiunea de Sesiuni Active */}
                        <section>
                            <div className="mb-4 flex items-center justify-between">
                                <h2 className={cardTitleClass}>Your Active Sessions</h2>
                                <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
                                    {sessions.length} Active
                                </span>
                            </div>
                            <SessionsCard
                                sessions={sessions}
                                formatSessionTime={formatSessionTime}
                                onLeaveSession={onLeaveSession}
                            />
                        </section>

                        {/* Secțiunea de Creare Eveniment Manual */}
                        <section className={cardClass}>
                            <div className="p-6">
                                <h2 className={`${cardTitleClass} mb-6`}>Host a Session</h2>
                                <ManualEventCard
                                    sports={sports}
                                    locations={locations}
                                    onCreate={onCreateManualEvent}
                                />
                            </div>
                        </section>
                    </div>

                    {/* COLOANA 3: Matching și Disponibilitate */}
                    <div className="space-y-10">

                        {/* Cardul de Matching (Algoritm) */}
                        <section>
                            <MatchCard
                                onRunMatch={onRunMatch}
                                loading={matching}
                            />
                        </section>

                        {/* Cardul de Disponibilitate */}
                        <section>
                            <AvailabilityCard
                                availability={availability}
                                onUpdate={onUpdateAvailability}
                            />
                        </section>

                        {/* Mică notă informativă */}
                        <div className="rounded-2xl bg-slate-50 p-6 text-sm text-slate-500 shadow-inner">
                            <p className="italic">
                                "Matching uses your availability and skill level to find the perfect group for you. Make sure your profile is up to date!"
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </main>
    )
}