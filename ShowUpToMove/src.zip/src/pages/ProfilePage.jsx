import ProfileCard from '../components/ProfileCard'
import NoticeBanner from '../components/NoticeBanner'

/**
 * Pagina de Profil - permite utilizatorului sa isi seteze nivelul de abilitate,
 * sporturile preferate si sa isi gestioneze datele personale.
 */
export default function ProfilePage({
    user,
    allSports,
    notice,
    errorMessage,
    onUpdateProfile
}) {
    return (
        <main className="mx-auto max-w-4xl px-6 py-10">
            <div className="soft-rise space-y-8">
                {/* Sectiune de titlu si introducere */}
                <header className="text-center md:text-left">
                    <h1 className="text-3xl font-bold text-slate-800 tracking-tight">
                        Personal Profile
                    </h1>
                    <p className="mt-2 text-slate-600">
                        Customize your sports preferences to get better matches and session recommendations.
                    </p>
                </header>

                {/* Banner pentru alerte (succes sau eroare) */}
                <NoticeBanner notice={notice} error={errorMessage} />

                <div className="grid grid-cols-1 gap-8">
                    {/* Componenta principala de editare profil */}
                    <ProfileCard
                        user={user}
                        allSports={allSports}
                        onUpdateProfile={onUpdateProfile}
                    />

                    {/* Sectiune informativa suplimentara */}
                    <div className="rounded-2xl border border-slate-100 bg-white/30 p-6 text-sm text-slate-500">
                        <h3 className="mb-2 font-semibold text-slate-700">How matching works?</h3>
                        <p>
                            Your skill level and favorite sports are used by our matching algorithm
                            to find teammates with similar interests and abilities nearby.
                            Keep these updated for the best experience!
                        </p>
                    </div>
                </div>
            </div>
        </main>
    )
}